from setuptools import setup

setup(name='zq_simple_math',
      version='1.0',
      description='Example package',
      url='https://github.com/uu-python/travis-fib',
      author='ZQ',
      license='BSD',
      py_modules=['fib'],
      package=[])